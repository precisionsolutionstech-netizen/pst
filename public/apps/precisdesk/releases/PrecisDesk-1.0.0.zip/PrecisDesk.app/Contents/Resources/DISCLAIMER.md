# PrecisDesk Disclaimer

**Last updated:** September 7, 2026

PrecisDesk can capture your screen, record video and audio, use your camera, recognise text in images, move and close other applications' windows, and print.

Please read this before using it.

## Recording and capture are your responsibility

**Laws about recording are strict and vary by place.** In many jurisdictions it is a criminal offence to record a conversation, call, or meeting without the consent of everyone involved. Additional rules apply in workplaces, schools, and healthcare settings, and to anyone covered by data protection law such as the GDPR or UK GDPR.

Before you record or capture anything, it is **your** responsibility to:

- Obtain consent from everyone whose voice, image, screen, communications, or personal data might be captured
- Comply with all applicable recording, wiretap, privacy, confidentiality, and data protection laws
- Respect contracts, workplace policies, terms of service, and duties of confidentiality
- Avoid capturing credentials, payment details, health information, trade secrets, or copyrighted material you have no right to use
- Handle what you captured responsibly afterwards

Precision Solutions cannot see what you capture and has no way to know whether you were permitted to capture it. **We accept no responsibility for what you record, capture, print, or share.**

## Window management

PrecisDesk uses macOS Accessibility permission to move, resize, arrange, minimise, close, and quit other applications' windows. **Closing or quitting an application can lose unsaved work.** You are responsible for the consequences of the actions you trigger.

## Printing

PrecisDesk can print an image through the standard macOS print panel. We are not responsible for documents printed, misprinted, delayed, or lost, for printer or driver behaviour, or for consumables used.

## Your files

Keep your own backups and verify them. PrecisDesk writes files to locations you choose and deletes captures from its history according to a retention setting you control. We do not guarantee that any capture, recording, export, text recognition, or print job will be complete, accurate, or successful.

## No warranty, no liability

PrecisDesk is provided **AS IS**, without warranty of any kind. Use it entirely at your own risk.

To the fullest extent permitted by law, Precision Solutions has **no liability** for data loss, failed or unusable recordings, print failures or disclosure of printed content, privacy incidents, regulatory or legal proceedings brought against you, lost profits, business interruption, or any other damages — with total liability of **US $0** where permitted. Where a jurisdiction does not allow complete exclusion, liability is limited to the fullest extent that jurisdiction allows.

## Agreement

By using PrecisDesk you agree to the [EULA](EULA.md) and the [Privacy Policy](PRIVACY.md), which govern in full and control over any summary here.
