# PrecisDesk End User License Agreement (EULA)

**Last updated:** September 7, 2026

This End User License Agreement (“Agreement”) is a legal agreement between you (“you” or “User”) and Precision Solutions, the publisher of PrecisDesk (“Licensor”), for the PrecisDesk desktop software application, including any updates, documentation, and related materials (the “Software”).

By downloading, installing, opening, or using the Software, or by clicking “I Agree”, you agree to be bound by this Agreement. If you do not agree, do not install or use the Software.

## 1. License grant

Subject to this Agreement, Licensor grants you a personal, non-exclusive, non-transferable, revocable license to install and use the Software on Apple-branded computers that you own or control, for your personal or internal business use.

## 2. Ownership

The Software is licensed, not sold. Licensor retains all right, title, and interest in and to the Software, including all intellectual property rights. This Agreement does not grant you any rights to trademarks or branding except as needed to use the Software.

## 3. Restrictions

You may not: (a) reverse engineer, decompile, or disassemble the Software except to the extent such restriction is prohibited by law; (b) rent, lease, lend, sell, sublicense, or redistribute the Software except as expressly allowed by Licensor; (c) remove proprietary notices; (d) use the Software to violate any law or third-party rights; or (e) attempt to circumvent license, security, or safety features.

## 4. Recording, capture, and consent — your responsibility

**This is the most important section of this Agreement. Read it.**

The Software can capture your screen, record video of your screen, record audio from your microphone and from your computer's audio output, capture images of other applications' windows, recognise text in images, and capture video from a connected camera.

**You are solely responsible for determining whether, and how, you may lawfully record or capture anything.** Laws governing the recording of audio, video, conversations, meetings, calls, and screen content vary widely and are frequently strict. In many jurisdictions, recording a conversation without the consent of every participant is a criminal offence, a civil wrong, or both. Requirements differ between one-party consent and all-party consent jurisdictions, and additional rules may apply in workplaces, schools, healthcare settings, and to anyone in the European Union, the United Kingdom, or other regions with comprehensive data protection law.

You agree that you, and not Licensor, are responsible for:

- Obtaining all consents, permissions, notices, and authorisations required before recording or capturing anything, from every person whose voice, image, screen, data, or communications may be captured;
- Complying with all applicable wiretap, eavesdropping, privacy, publicity, biometric, data protection, employment, confidentiality, and recording-consent laws;
- Complying with any contract, workplace policy, terms of service, licence, or duty of confidentiality that applies to material you capture;
- Not capturing content you have no right to capture, including copyrighted works, other people's personal data, protected health information, payment card data, credentials, or trade secrets;
- Everything you do with a capture after it is made, including storing, editing, publishing, transmitting, or sharing it.

Licensor has no knowledge of and no control over what you capture. Licensor does not review, monitor, receive, or store your captures. **Licensor accepts no responsibility or liability of any kind for what you record, capture, print, share, or do with the Software.**

## 5. Window management and accessibility access

The Software can move, resize, arrange, minimise, and close windows belonging to other applications, using macOS Accessibility permission that you grant explicitly. You are responsible for the consequences of those actions, including any unsaved work lost when a window is closed or an application is quit, and for deciding whether granting Accessibility access is appropriate on your machine.

## 6. Printing

The Software can print an image through the standard macOS print panel, and can write print output as PDF or PNG into folders you choose.

Licensor is not responsible for documents printed, misprinted, delayed, or lost, for printer or driver behaviour, or for consumables used. You are responsible for the content of anything you print.

## 7. User responsibilities and backups

**You are solely responsible for your files and data.** Keep and verify your own backups.

The Software writes captures, recordings, exports, project files, and print output to locations you choose, and can delete captures from its own history according to a retention setting you control. You are responsible for reviewing what it does and for confirming actions before you take them.

Licensor does not guarantee that any capture, recording, export, text recognition, print job, or window action will be complete, accurate, or error-free.

## 8. No warranty

THE SOFTWARE IS PROVIDED “AS IS” AND “AS AVAILABLE,” WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, NON-INFRINGEMENT, ACCURACY, OR QUIET ENJOYMENT. LICENSOR DOES NOT WARRANT THAT THE SOFTWARE WILL BE UNINTERRUPTED, ERROR-FREE, OR FREE OF HARMFUL COMPONENTS, THAT ANY RECORDING OR CAPTURE WILL SUCCEED OR BE USABLE, THAT ANY PRINT JOB WILL COMPLETE, OR THAT RESULTS WILL MEET YOUR REQUIREMENTS.

Some jurisdictions do not allow exclusion of certain warranties; in those cases, the above exclusions apply to the maximum extent permitted by law.

## 9. No liability

YOU USE THE SOFTWARE ENTIRELY AT YOUR OWN RISK.

TO THE MAXIMUM EXTENT PERMITTED BY LAW, LICENSOR AND ITS AFFILIATES, OFFICERS, EMPLOYEES, AGENTS, AND SUPPLIERS SHALL HAVE **NO LIABILITY WHATSOEVER** — INCLUDING ZERO LIABILITY FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, PUNITIVE, OR ANY OTHER DAMAGES — AND NO LIABILITY FOR ANY LOSS, CORRUPTION, OR DELETION OF DATA OR FILES; ANY FAILED, INCOMPLETE, OR UNUSABLE RECORDING OR CAPTURE; ANY PRINT FAILURE, MISPRINT, OR DISCLOSURE OF PRINTED CONTENT; ANY CLAIM ARISING FROM WHAT YOU RECORDED, CAPTURED, OR SHARED; ANY REGULATORY, CRIMINAL, OR CIVIL PROCEEDING BROUGHT AGAINST YOU; OR LOSS OF PROFITS, GOODWILL, OR BUSINESS INTERRUPTION, ARISING OUT OF OR RELATED TO THE SOFTWARE OR THIS AGREEMENT, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, STATUTE, OR ANY OTHER LEGAL THEORY, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, AND EVEN IF A REMEDY FAILS OF ITS ESSENTIAL PURPOSE.

TO THE MAXIMUM EXTENT PERMITTED BY LAW, LICENSOR’S TOTAL LIABILITY FOR ALL CLAIMS ARISING OUT OF OR RELATED TO THE SOFTWARE OR THIS AGREEMENT IS **US $0 (ZERO)**. YOU AGREE THAT THIS ZERO-LIABILITY ALLOCATION IS A FUNDAMENTAL BASIS OF THE BARGAIN AND THAT THE SOFTWARE WOULD NOT BE OFFERED TO YOU ON THESE TERMS WITHOUT IT.

If any jurisdiction does not allow a complete exclusion of liability, then Licensor’s liability shall be excluded and limited to the fullest extent that jurisdiction allows, and in all events shall be US $0 where that result is permitted.

## 10. Indemnity

You agree to defend, indemnify, and hold harmless Licensor and its affiliates, officers, employees, and agents from and against any and all claims, damages, losses, liabilities, and expenses (including reasonable attorneys’ fees) arising out of or related to: your use of the Software; anything you captured, recorded, printed, shared, or published; any allegation that a capture or recording you made was unlawful or unauthorised; your files or data; your network configuration; or your breach of this Agreement.

## 11. Privacy

The Software is designed to process captures, recordings, text recognition, and print jobs locally on your device. See the Privacy Policy for details. Licensor does not need or receive your captures to operate the Software.

## 12. Termination

This license terminates automatically if you breach this Agreement. You may stop using the Software at any time by uninstalling it. Sections 2–11 and 13–15 survive termination.

## 13. Updates

Licensor may provide updates. Updates may be subject to this Agreement or additional terms. Licensor is not obligated to provide support, maintenance, or updates.

## 14. Governing law

This Agreement is governed by the laws of the jurisdiction in which Licensor principally resides, excluding conflict-of-law rules, unless mandatory consumer protections in your place of residence require otherwise. Courts in that jurisdiction shall have exclusive jurisdiction, subject to mandatory consumer venue rights.

## 15. Miscellaneous

This Agreement is the entire agreement regarding the Software and supersedes prior or contemporaneous understandings on that subject. If any provision is unenforceable, the remainder remains in effect. Failure to enforce a provision is not a waiver. You may not assign this Agreement without Licensor’s consent; Licensor may assign it.

If you obtained the Software through the Apple App Store, additional terms apply: this Agreement is between you and Licensor only, not Apple; Apple has no obligation to provide support or maintenance for the Software; Apple is not responsible for any claim relating to the Software; and Apple and its subsidiaries are third-party beneficiaries of this Agreement and may enforce it against you.

## Contact

For licensing questions, contact the address published on the PrecisDesk product page or your purchase receipt.
