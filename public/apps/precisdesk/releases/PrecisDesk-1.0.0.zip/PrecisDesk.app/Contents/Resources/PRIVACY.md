# PrecisDesk Privacy Policy

**Last updated:** September 7, 2026

This Privacy Policy describes how PrecisDesk (“we”, “us”) handles information when you use the PrecisDesk macOS application (the “App”), published by Precision Solutions.

## Short version

PrecisDesk runs **on your Mac**. Your screenshots, screen recordings, audio, camera video, and recognised text are processed locally and are never sent to us. We operate no account system and no media servers. We cannot see anything you capture.

## What the App processes locally

Depending on which features you use, the App processes on your device:

- **Screen captures and recordings** — images and video of the screens, windows, or regions you choose to capture, written to a folder you choose
- **Microphone audio and system audio** — only while you are recording and only if you enable those inputs
- **Camera video** — only if you enable webcam picture-in-picture
- **Recognised text** — text recognition (OCR) runs on-device using Apple's Vision framework; images are not uploaded
- **Speech recognition** — if you use automatic captions, speech recognition runs on-device using Apple's Speech framework
- **Capture history** — a local index of captures you have made (file paths, timestamps, type, size), with a retention period you control
- **Window information** — titles, owning applications, and positions of open windows, used to list and arrange them
- **Printing** — the printer you choose and the document you print, handled by macOS
- **Your settings** — capture folders, filename templates, hotkeys, and window rules, stored in local preferences

This processing stays on your device unless you independently copy, print, or share the result.

## Other people's information, and consent

A screen recording, a microphone recording, or a camera capture may contain other people's voices, faces, messages, or personal data. When that happens, **you** decide what is captured and what happens to it afterwards — we never see it and have no control over it. Under data protection laws such as the GDPR and UK GDPR, that generally makes you the controller of that information, not us.

It is your responsibility to obtain any consent the law requires from everyone who may be recorded or captured, to tell them what you are doing where that is required, and to handle the result lawfully. Recording-consent rules are strict in many places and differ between jurisdictions. See the Disclaimer and the EULA.

## macOS permissions the App may request, and why

- **Screen Recording** — required to take screenshots or record the screen
- **Microphone** — only to include your voice in a recording
- **Camera** — only for webcam picture-in-picture
- **Speech Recognition** — only for on-device automatic captions
- **Accessibility** — to move, resize, and arrange windows belonging to other applications

You may grant or revoke any of these in System Settings. Features that depend on a permission you decline simply do not run.

## Printing

Printing goes through the standard macOS print system to a printer you select. **Nothing you print is sent to us.**

## Login Items

If you enable “Launch at login”, the App registers itself as a macOS Login Item so it can start with your session. You can turn this off in the App's settings or under System Settings → General → Login Items.

## Network access

- **Direct (non–App Store) builds** check for updates once per day by requesting an update feed from `precisionsolutionstech.com`. Like any web request, this discloses your IP address, approximate time, and standard request headers to that server. It does not include your captures, files, or personal information. You can stop these checks by quitting the App.
- **Mac App Store builds** contain no update mechanism of their own; updates come from Apple.
- The App does not require internet access for capture, recording, editing, text recognition, window management, or printing.

## What we receive if you buy or contact us

If you purchase a licence or contact support through a storefront (for example the Mac App Store, Gumroad, or Stripe) or by email:

- The storefront's privacy policy governs checkout and payment data. We do not receive your full payment card number.
- We may receive your name, email address, purchase status, and the content of your support message, as needed to fulfil the purchase or reply to you.

## Analytics, tracking, and advertising

The App contains **no analytics SDKs, no advertising SDKs, and no third-party trackers**. We do not profile you, and we do not sell or share personal information. If analytics are ever added, this policy will be updated before that change ships, and any collection would be opt-in.

## Data retention

Captures, recordings, exports, and history remain on your Mac until you delete them, until the retention period you set removes them, or until you uninstall the App. Purchase and support records held by us or a storefront are retained as needed for accounting, fraud prevention, and customer support.

## Your rights and choices

- Capture only what you intend to capture, and review it before sharing
- Leave microphone, system audio, and camera inputs off (they are off by default)
- Set the capture retention period, or delete captures individually
- Decline or revoke any macOS permission in System Settings
- Uninstall the App to stop all local processing

Because we do not collect your personal information, there is generally nothing for us to export or delete on request. If you have contacted support or made a purchase, you may ask us about the records associated with that.

## Children's privacy

The App is not directed to children under 13 (or the minimum age in your jurisdiction).

## Changes

We may update this policy. The “Last updated” date will change when we do. Continued use after an update means you accept the revised policy for subsequent use.

## Contact

Use the contact method on the PrecisDesk product page or your purchase receipt.
