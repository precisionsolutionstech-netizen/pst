# Twinkeep Disclaimer

**Last updated:** August 5, 2026

Twinkeep helps you find and manage duplicate media files. It is a utility, not a backup service, data-recovery service, or professional archival system.

## Please read this

1. **Back up first.** Always keep a verified backup of important photos, videos, and audio before using Twinkeep.
2. **You control destructive actions.** Quarantine and deletion decisions are yours. Auto-quarantine for exact duplicates only runs if you enable it (it is configurable in Settings).
3. **Detection is not perfect.** Exact matching uses cryptographic hashing of file contents. Near-duplicate photo matching uses similarity heuristics and can be wrong. Different encodings of the “same” video or song are not treated as exact duplicates.
4. **Quarantine is not a substitute for backups.** Quarantined files can still be permanently deleted by you, by emptying quarantine, by disk failure, or by uninstalling without restoring.
5. **No liability — zero.** You use Twinkeep at your own risk. To the fullest extent permitted by law, the publisher of Twinkeep has **no liability** for lost, damaged, overwritten, misplaced, quarantined, or deleted files, or for any damages of any kind arising from the Software. Where a complete exclusion is not allowed, liability is excluded to the maximum extent permitted and is US $0 where permitted.
6. **Not legal, medical, or professional advice.** This product and its documentation do not create a professional-services relationship.

By using Twinkeep, you acknowledge that you understand these risks and agree to the EULA.
