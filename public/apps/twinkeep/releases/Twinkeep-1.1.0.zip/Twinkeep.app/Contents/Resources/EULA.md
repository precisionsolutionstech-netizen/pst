# Twinkeep End User License Agreement (EULA)

**Last updated:** August 5, 2026

This End User License Agreement (“Agreement”) is a legal agreement between you (“you” or “User”) and the publisher of Twinkeep (“Licensor”) for the Twinkeep desktop software application, including any updates, documentation, and related materials (the “Software”).

By downloading, installing, opening, or using the Software, or by clicking “I Agree”, you agree to be bound by this Agreement. If you do not agree, do not install or use the Software.

## 1. License grant

Subject to this Agreement, Licensor grants you a personal, non-exclusive, non-transferable, revocable license to install and use the Software on Apple-branded computers that you own or control, for your personal or internal business use.

## 2. Ownership

The Software is licensed, not sold. Licensor retains all right, title, and interest in and to the Software, including all intellectual property rights. This Agreement does not grant you any rights to trademarks or branding except as needed to use the Software.

## 3. Restrictions

You may not: (a) reverse engineer, decompile, or disassemble the Software except to the extent such restriction is prohibited by law; (b) rent, lease, lend, sell, sublicense, or redistribute the Software except as expressly allowed by Licensor; (c) remove proprietary notices; (d) use the Software to violate any law or third-party rights; or (e) attempt to circumvent license, security, or safety features.

## 4. User responsibilities and backups

**You are solely responsible for your files and data.**

Before scanning, quarantining, moving, or deleting any files, you should create and verify your own backups. Twinkeep can move or remove files you select (or that you configure for automatic exact-duplicate quarantine). You are responsible for reviewing results, choosing what to keep, and confirming actions.

Licensor does not guarantee that duplicate detection is complete or error-free. “Exact” matches are based on content hashing; “Review” / near-duplicate suggestions are probabilistic and may incorrectly group or miss files.

## 5. No warranty

THE SOFTWARE IS PROVIDED “AS IS” AND “AS AVAILABLE,” WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, NON-INFRINGEMENT, ACCURACY, OR QUIET ENJOYMENT. LICENSOR DOES NOT WARRANT THAT THE SOFTWARE WILL BE UNINTERRUPTED, ERROR-FREE, OR FREE OF HARMFUL COMPONENTS, OR THAT RESULTS WILL MEET YOUR REQUIREMENTS.

Some jurisdictions do not allow exclusion of certain warranties; in those cases, the above exclusions apply to the maximum extent permitted by law.

## 6. No liability

YOU USE THE SOFTWARE ENTIRELY AT YOUR OWN RISK.

TO THE MAXIMUM EXTENT PERMITTED BY LAW, LICENSOR AND ITS AFFILIATES, OFFICERS, EMPLOYEES, AGENTS, AND SUPPLIERS SHALL HAVE **NO LIABILITY WHATSOEVER** — INCLUDING ZERO LIABILITY FOR DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, EXEMPLARY, PUNITIVE, OR ANY OTHER DAMAGES — AND NO LIABILITY FOR ANY LOSS, CORRUPTION, DELETION, QUARANTINE, OR MISPLACEMENT OF DATA OR FILES, LOSS OF PROFITS, GOODWILL, OR BUSINESS INTERRUPTION, ARISING OUT OF OR RELATED TO THE SOFTWARE OR THIS AGREEMENT, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, STATUTE, OR ANY OTHER LEGAL THEORY, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, AND EVEN IF A REMEDY FAILS OF ITS ESSENTIAL PURPOSE.

TO THE MAXIMUM EXTENT PERMITTED BY LAW, LICENSOR’S TOTAL LIABILITY FOR ALL CLAIMS ARISING OUT OF OR RELATED TO THE SOFTWARE OR THIS AGREEMENT IS **US $0 (ZERO)**. YOU AGREE THAT THIS ZERO-LIABILITY ALLOCATION IS A FUNDAMENTAL BASIS OF THE BARGAIN AND THAT THE SOFTWARE WOULD NOT BE OFFERED TO YOU ON THESE TERMS WITHOUT IT.

If any jurisdiction does not allow a complete exclusion of liability, then Licensor’s liability shall be excluded and limited to the fullest extent that jurisdiction allows, and in all events shall be US $0 where that result is permitted.

## 7. Indemnity

You agree to defend, indemnify, and hold harmless Licensor and its affiliates, officers, employees, and agents from and against any and all claims, damages, losses, liabilities, and expenses (including reasonable attorneys’ fees) arising out of or related to your use of the Software, your files or data, your decisions to quarantine or delete files, or your breach of this Agreement.

## 8. Privacy

The Software is designed to process files locally on your device. See the Privacy Policy for details. Licensor does not need your media files to operate the core duplicate features.

## 9. Termination

This license terminates automatically if you breach this Agreement. You may stop using the Software at any time by uninstalling it. Sections 2–7 and 10–12 survive termination.

## 10. Updates

Licensor may provide updates. Updates may be subject to this Agreement or additional terms. Licensor is not obligated to provide support, maintenance, or updates.

## 11. Governing law

This Agreement is governed by the laws of the jurisdiction in which Licensor principally resides, excluding conflict-of-law rules, unless mandatory consumer protections in your place of residence require otherwise. Courts in that jurisdiction shall have exclusive jurisdiction, subject to mandatory consumer venue rights.

## 12. Miscellaneous

This Agreement is the entire agreement regarding the Software and supersedes prior or contemporaneous understandings on that subject. If any provision is unenforceable, the remainder remains in effect. Failure to enforce a provision is not a waiver. You may not assign this Agreement without Licensor’s consent; Licensor may assign it.

## Contact

For licensing questions, contact the address published on the Twinkeep product page or purchase receipt.
