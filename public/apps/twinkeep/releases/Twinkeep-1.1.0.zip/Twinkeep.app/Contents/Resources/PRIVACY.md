# Twinkeep Privacy Policy

**Last updated:** August 6, 2026

This Privacy Policy describes how Twinkeep (“we”, “us”) handles information when you use the Twinkeep macOS application (the “App”).

## Short version

Twinkeep is built to work **on your Mac**. Core scanning and duplicate detection read files you choose and do not require uploading your media to our servers.

## Information the App processes locally

When you use the App, it may process on your device:

- Paths and metadata of files in folders you select (name, size, dates, media type)
- Content fingerprints (hashes) computed locally to detect duplicates
- Thumbnails or previews generated locally for display
- Your settings (for example, auto-quarantine preference) stored in local preferences
- Quarantine records stored in your user Application Support folder
- Optional Stability monitor samples (approximate per-app CPU and memory, thermal state, timestamps) stored only on your Mac for up to about 7 days, and only while you leave that monitor running
- Paths and timestamps of macOS DiagnosticReports (crash/hang logs) that the Stability utility lists for aftercare — read locally, never uploaded

This processing stays on your device unless you independently copy or share files.

## Login Items (optional Stability monitor)

If you start the optional background Stability monitor, Twinkeep may register itself as a macOS Login Item so sampling can resume after reboot. You can quit the monitor from the menu bar icon or disable Twinkeep under System Settings → General → Login Items. Quitting the monitor stops new samples and removes that relaunch preference when possible.

## Information we may receive if you buy or contact us

If you purchase a license or contact support through a storefront (for example Gumroad or Polar) or email:

- The storefront’s privacy policy governs checkout and payment data (we do not receive your full payment card number)
- We may receive your name, email, purchase status, and support message content as needed to fulfill the purchase or reply

## Analytics, tracking, and advertising

The current App does **not** include third-party advertising SDKs or sell your personal information. If analytics are added later, this policy will be updated before that change ships.

## Internet access

The App does not need internet access for local scanning, quarantine, restore, or Stability monitoring. Future optional features (license validation, updates) may use the network; if so, they will be described in an updated policy.

## Data retention

Local scan results and quarantine data remain on your Mac until you remove them or uninstall the App. Stability samples are pruned after about 7 days (and stop accumulating when the monitor is quit). Purchase/support records are retained as needed for accounting, fraud prevention, and customer support.

## Children’s privacy

The App is not directed to children under 13 (or the minimum age in your jurisdiction).

## Your choices

- Only select folders you intend to scan
- Disable auto-quarantine in Settings
- Restore or permanently delete quarantined items
- Leave the Stability monitor off (default), or quit it anytime from the menu bar
- Uninstall the App to stop local processing

## Changes

We may update this policy. The “Last updated” date will change when we do. Continued use after an update means you accept the revised policy for subsequent use.

## Contact

Use the contact method on the Twinkeep product page or your purchase receipt.
